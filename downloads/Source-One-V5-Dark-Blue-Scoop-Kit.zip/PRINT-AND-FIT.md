# TBS Source One V5 · Reinforced dark-blue print kit

The kit illustrates dark-blue prints and camera housing, graphite motor bells, and a black Axisflying Argus ECO F405/60A stack on the graphite frame. The hardware in the renders and GLB is a visual approximation. The actual motor and camera colors depend on the hardware you own.

Use **`fit-fix-print-plate.3mf`** for the revised parts. It contains one stack shroud, one camera cradle and four handed wire holders. The complete **`dark-blue-print-plate.3mf`** contains 16 pieces including the tilt gauge and bolt-free landing shoes. Both plates use millimeters and a dark-blue material swatch. Select 95A TPU and your printer profile. The GLB is a separate assembled preview. `revision-preview.png` shows the four-post shroud, camera bridge, wire entry and tape surface. `camera-wire-preview.jpg` shows the assembled nose and the harness underneath.

| STL | Print | Fit |
|---|---:|---|
| `phoenix2-cradle.stl` | 1 | One-piece Phoenix 2 cradle with two closed nose sleeves, a low front bridge and one M2 pivot per side |
| `camera-tilt-gauge.stl` | 1 | Loose 15° setup gauge |
| `sma.stl` | 1 | 30° upward rear SMA bulkhead, 6.55 mm bore with one flat, 3.2 mm panel |
| `elrs.stl` | 1 | Tie-down tray for a heat-shrunk 2.4 GHz ELRS receiver, up to 14.5 × 24 mm |
| `wire_right.stl` and `wire_left.stl` | 2 each | 45 mm wire holders with a flat tape sole and a 1.5 mm press-in opening |
| `arm-strap-right.stl` and `arm-strap-left.stl` | 2 each | Bolt-free TPU shoes retained by a tie at the motor-side band of each holder |
| `arm-right16.stl` and `arm-left16.stl` | Alternate | Faceted wraparound landing bumpers for 16 × 16 mm M3 motor patterns |
| `arm-right19.stl` and `arm-left19.stl` | Alternate | Wraparound bumpers for 19 × 19 mm M3 motor patterns |
| `front-skid.stl` and `rear-skid.stl` | 1 each | Low nose and tail protection on the existing lower post screw locations |
| `stack-shroud.stl` | 1 | Four-post shroud with framed USB windows, twin forward scoops and side walls extending to the camera |
| `antenna.stl` | 1 optional | Low rear tab for a horizontal 2.4 GHz T antenna |

## Print

- Start with **95A TPU**, a 0.4 mm nozzle, 0.2 mm layers, four walls and 20–30% infill. Use your filament’s temperature and speed profile. The replacement STLs and both 3MFs are oriented for printing.
- Print the **wire holders flat sole down**, on a smooth bed face. Print the **camera cradle bridge down**, with the post bores vertical. Print the **stack shroud on its flat tail end**, in the supplied orientation. Its two window ends taper as the print grows. Use a 5 mm brim on the shroud if your printer needs more bed adhesion. Keep support out of the wire slots, camera bores and intake passages. Inspect the first layers and clear any stringing before assembly.
- Print the landing shoes tread down. Clear the transverse tie tunnels before assembly. Localized support may help at the angled SMA seat or in the bolt-on bumper pockets.

## Install

1. **Camera cradle.** With the upper carbon plate off, slide both short sleeves over the outer nose posts on the 19 mm pitch. Seat the low bridge on the nose plate, in front of the camera. The rear is open for the plug. Insert the 19 mm Phoenix 2 case from the rear. Start one M2 screw on each side before tightening either. The cheek gap is 19.3 mm and the screw passes through 3.4 mm of TPU at the seat. Choose its length to suit the thread depth in your camera. Loosening the two screws adjusts tilt about their common axis, 19.1 mm behind the nose posts. The top plate captures the raised cheek pads when reinstalled.

   Start at **15° or less** with a wide lens. A 16.8 mm barrel cleared the TPU and stock frame at 0–17° in CAD. It first touched the underside of the stock top plate at 18°. The standard 13.9 mm barrel cleared at 0–20°. The 6.5 mm openings at the tips of the shroud give driver access to these screws. Fit the top plate and verify the lens gap, live view and cable route at your chosen angle.

2. **SMA.** Slide the angled mount onto the outer 22 mm-spaced tail posts. The SMA connector points aft and 30° up. Set the mount’s underside about 14.5 mm above the lower tail plate, and capture it vertically with tubing or split spacers. Check the connector body and flat, washer seating, and thread engagement through the 3.2 mm panel. The outer face accepts a straight SMA antenna. Leave slack in the pigtail and verify clearance to the battery and straps. Check the assembled video link in your usual flight attitude, since signal quality depends on antenna orientation and the receiving setup.
3. **ELRS receiver.** Install the tray facing aft on the inner 20 mm-spaced tail posts. Set its underside about 10.5 mm above the lower tail plate. The illustrated BETAFPV Nano 2.4 GHz receiver has a 12 × 19 mm footprint. Thread the ties through the larger rounded slots before placing the receiver. Check your heat shrink and plug exit, and leave slack at the U.FL connector.
4. **2.4 GHz T antenna.** Slide the low tab onto the outer rear posts, directly beneath the SMA holder, with the tab facing aft. Set its underside about 3.3 mm above the lower tail plate. Pass one slim zip tie through the 3.15 × 1.65 mm slot and around the molded center of the antenna. Keep the 60 mm crossbar level and centered. Route the 80 mm coax past the SMA bracket, with slack by the U.FL connector. The ends overlap the rear 5-inch prop disks in plan view and rely on vertical separation. The modeled clearance is about 10.7 mm below an assumed lower blade envelope at Z=22 mm. With the battery unplugged, rotate the actual props by hand and flex the antenna upward to verify clearance before flying. A shorter compatible T antenna with a measured crossbar of about 40 mm keeps the tips outside the nominal 5-inch disks in this layout. The VTX antenna shown in the assembly is a visual placeholder.
5. **Tape-mounted wire holders.** Use the right version on the front-right and rear-left arms, the left version on the other diagonal. Each 45 mm sole follows the arm taper. The wider end points toward the stack. Place the motor-side end **20 mm from the motor shaft center**, measured along the arm. Cut **one 6 × 41 mm strip of double-sided 3M tape per arm**, center it on the flat underside and press it onto clean carbon per your tape’s instructions. A 0.5 mm tape layer was used in the assembly model. The geometry was also checked at 0.2 and 1.0 mm. Use tape suitable for your particular TPU and frame finish, and check the bond by hand. Press the three leads one at a time through the flexible top slit. The passage was checked with three 2.2 mm insulated wires. Keep slack at both ends and ensure the wires stay below the lips.
6. **Bolt-free motor-end bumpers.** The wire holder mounts with tape alone. Each bolt-free shoe still needs its own **3.6 mm zip tie**. With props off, seat the bumper from below, thread its tie through the transverse tunnel and loop it over the shallow band in the wire holder, 34 mm from the motor center. Keep the tie head low on the side. The shoe pocket is 26.6 mm across and about 4.6 mm deep. Check clearance to the installed screw heads and the shaft, then pull and twist the shoe by hand. Check it again after a hard landing.

   For the **bolt-on alternatives**, match the motor’s 16 mm or 19 mm square pattern. These versions add a nominal 3.1 mm under the motor screw heads. Verify thread engagement, motor winding clearance, and shaft-clip clearance.

7. **Front and rear skids.** Seat each skid against the underside of its end plate. It uses the two existing lower screws on the 19 mm front or 22 mm rear posts. The recessed screw seats add about 2.9 mm to the required length. The recesses are 7.2 mm across, with flared entrances. Verify thread engagement and that screws do not bottom in the posts. The skid bottoms sit slightly above the motor-foot landing plane so the four feet take a level landing.
8. **Stack shroud and USB.** Remove the top plate and fit the camera cradle first. Plug in the camera and route its harness down the center between the forward posts. Slide the single shroud over the four inner posts, with the two scoops toward the camera and the straight crossbar aft. Its nose walls slide **outside** the camera cheeks. Match the two round access holes to the camera screws. The front sleeves seat on the lower nose plate and locate the shroud vertically. The short rear mounts sit above the ELRS tray. Guide each motor bundle through an end of the side window, leaving the middle clear for the USB plug. Refit the carbon top plate and check full USB plug seating and clearance to solder joints, wiring and propellers.

   The shroud sides extend about 27 mm beyond the scoop faces. They overlap the camera cheeks by about 11 mm at harness height. Each overlap has about 0.5 mm of hidden fitting clearance. Both sides cover the harness between the lower and upper plates, and the rear of the camera remains accessible from above when the top plate is off. A 4 mm cable bundle and a 4.8 mm driver shank cleared in CAD. Check for a free harness loop and for pinched insulation before fitting the top plate.

   The side openings have unbroken upper and lower rails. In CAD, a 13 × 8 mm plug housing passes through either window with its center up to 5.5 mm fore or aft of the stack center and 6.3–14.0 mm above the top of the central lower carbon plate. A centered plug also cleared at 5.1 mm above that plate. The scoop passages open inward toward the board. Airflow, cooling, adhesive retention and impact strength need physical testing.

## Installed FT800 VTX

The assembly shows the T-Motor FT800 5.8 GHz VTX, rated up to 800 mW, in the rear lower bay beneath the ELRS tray. The approximate 23.5 × 21 mm case envelope, with separate mounting ears, cleared the frame and tray in CAD. The supplied stock frame CAD does not show a full 20 × 20 mm hole pattern in this bay. The model shows the VTX in its existing rear position using an assumed placement, with the mounting hardware omitted because its exact arrangement was unspecified. The short MMCX-to-SMA route to the 30° tail bulkhead is schematic. Use your installed lead with a gentle bend and enough slack at both connectors. [T-Motor FT800 specifications](https://www.t-hobby.com/products/tmotor-ft800-vtx)

## Hardware shown in the assembly

- **EMAX ECO II 2306**, four motors. The 16 × 16 mm pattern matches the inner square of the frame’s motor mounting slots. [EMAX specifications](https://shop.emaxmodel.com/products/emax-eco-ii-series-2306-1700kv-1900kv-2400kv-brushless-motor-for-rc-drone-fpv-racing)
- **Axisflying Argus ECO F405 and 60A ESC**, centered on the frame’s 30.5 × 30.5 mm M3 pattern. The nominal board envelopes cleared the frame in CAD. Check the installed power leads, plugs, capacitor and soft-mount height with your actual stack. [Axisflying specifications](https://www.axisflying.com/products/argus-eco-60a-55a-f405-stack)
- **BETAFPV Nano ELRS 2.4 GHz receiver and 2.4 GHz dipole T antenna**, modeled with the 60 mm antenna crossbar and 80 mm U.FL lead option. [Receiver specifications](https://betafpv.com/products/elrs-nano-receiver) · [Dipole specifications](https://betafpv.com/products/betafpv-t-antenna-for-receiver)
- **Standard RunCam Phoenix 2**, illustrated with a dark-blue housing. The mount uses the 19 mm case width and M2 side mounting shown in the RunCam dimensional drawing. [RunCam Phoenix 2 manual](https://isdb-t.com/wp-content/uploads/2024/11/Phoenix_2-Manual.pdf)

## Edit the parts

Keep `arm-outline.scad` beside `sourceone-v5-kit.scad`. Choose a part in OpenSCAD Customizer, adjust its parameters, render with **F6**, and export an STL. The camera width, pivot and post bores, wire length and entry gap, and rear hardware mounts are editable.

All 16 individual STLs passed single-solid, closed-mesh checks. The four revised meshes were also sectioned at 0.2 mm in print orientation. Every new section connected to the preceding layer or the bed. Clearance checks used the supplied Source One V5 frame and modeled hardware envelopes. A physical print, tape bond, cable fit and camera sightline still need checking on the assembled quad.
